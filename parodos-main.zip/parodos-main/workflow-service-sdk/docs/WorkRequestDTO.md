

# WorkRequestDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**arguments** | [**List&lt;ArgumentRequestDTO&gt;**](ArgumentRequestDTO.md) |  |  [optional]
**type** | **String** |  |  [optional]
**workName** | **String** |  |  [optional]



