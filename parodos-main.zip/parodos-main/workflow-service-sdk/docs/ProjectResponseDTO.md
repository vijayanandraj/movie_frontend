

# ProjectResponseDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createDate** | **Date** |  |  [optional]
**description** | **String** |  |  [optional]
**id** | **String** |  |  [optional]
**modifyDate** | **Date** |  |  [optional]
**name** | **String** |  |  [optional]
**username** | **String** |  |  [optional]



