

# WorkFlowCheckerTaskRequestDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**StatusEnum**](#StatusEnum) |  |  [optional]



## Enum: StatusEnum

Name | Value
---- | -----
FAILED | &quot;FAILED&quot;
COMPLETED | &quot;COMPLETED&quot;
IN_PROGRESS | &quot;IN_PROGRESS&quot;



