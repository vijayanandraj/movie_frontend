

# WorkFlowRequestDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**arguments** | [**List&lt;ArgumentRequestDTO&gt;**](ArgumentRequestDTO.md) |  |  [optional]
**projectId** | **String** |  |  [optional]
**workFlowName** | **String** |  |  [optional]
**works** | [**List&lt;WorkRequestDTO&gt;**](WorkRequestDTO.md) |  |  [optional]



