

# WorkFlowOption


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  |  [optional]
**details** | **List&lt;String&gt;** |  |  [optional]
**displayName** | **String** |  |  [optional]
**identifier** | **String** |  |  [optional]
**workFlowName** | **String** |  |  [optional]



