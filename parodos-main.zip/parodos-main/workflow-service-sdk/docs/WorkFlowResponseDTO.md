

# WorkFlowResponseDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**workFlowExecutionId** | **String** |  |  [optional]
**workFlowOptions** | [**WorkFlowOptions**](WorkFlowOptions.md) |  |  [optional]
**workStatus** | [**WorkStatusEnum**](#WorkStatusEnum) |  |  [optional]



## Enum: WorkStatusEnum

Name | Value
---- | -----
FAILED | &quot;FAILED&quot;
COMPLETED | &quot;COMPLETED&quot;



