

# ProjectRequestDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  |  [optional]
**name** | **String** |  |  [optional]



