

# WorkFlowOptions


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**continuationOptions** | [**List&lt;WorkFlowOption&gt;**](WorkFlowOption.md) |  |  [optional]
**currentVersion** | [**WorkFlowOption**](WorkFlowOption.md) |  |  [optional]
**migrationOptions** | [**List&lt;WorkFlowOption&gt;**](WorkFlowOption.md) |  |  [optional]
**newOptions** | [**List&lt;WorkFlowOption&gt;**](WorkFlowOption.md) |  |  [optional]
**optionsAvailable** | **Boolean** |  |  [optional]
**otherOptions** | [**List&lt;WorkFlowOption&gt;**](WorkFlowOption.md) |  |  [optional]
**upgradeOptions** | [**List&lt;WorkFlowOption&gt;**](WorkFlowOption.md) |  |  [optional]



