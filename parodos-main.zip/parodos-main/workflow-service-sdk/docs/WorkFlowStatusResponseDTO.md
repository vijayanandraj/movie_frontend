

# WorkFlowStatusResponseDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** |  |  [optional]
**workFlowExecutionId** | **String** |  |  [optional]
**workFlowName** | **String** |  |  [optional]
**works** | [**List&lt;WorkStatusResponseDTO&gt;**](WorkStatusResponseDTO.md) |  |  [optional]



