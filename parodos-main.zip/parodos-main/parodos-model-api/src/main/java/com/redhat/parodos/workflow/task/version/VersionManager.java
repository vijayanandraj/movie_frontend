package com.redhat.parodos.workflow.task.version;

public interface VersionManager {

	String getVersion();

}
